/**
 * 
 */
/**
 * @author chaum
 *
 */
module j07009_lop_int_set_2 {
}