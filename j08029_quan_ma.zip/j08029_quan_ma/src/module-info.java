/**
 * 
 */
/**
 * @author chaum
 *
 */
module j08029_quan_ma {
}