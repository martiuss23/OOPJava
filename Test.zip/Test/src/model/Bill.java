package model;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;

public class Bill implements Comparable<Bill>{
    private static int index = 1;
    private String id_customer;
    private String name;
    private String id_room;
    private Date arrival_date;
    private Date department_date;
    private long service_fee;

    public Bill(String name, String id_room, String arrival_date, String department_date, long service_fee) throws ParseException {
        this.id_customer = "KH" + String.format("%02d", index++);
        Scanner scn = new Scanner(name);
		name = "";
		while(scn.hasNext()) {
			String token = scn.next();
			name += Character.toUpperCase(token.charAt(0)) + token.substring(1).toLowerCase() + " ";
		}
		scn.close();
        this.name = name.trim();

        this.id_room = id_room.trim();
        this.arrival_date = new SimpleDateFormat("dd/MM/yyyy").parse(arrival_date);
        this.department_date = new SimpleDateFormat("dd/MM/yyyy").parse(department_date);
        this.service_fee = service_fee;
    }

    public long getDays() {
        TimeUnit time = TimeUnit.DAYS;
        return time.convert(department_date.getTime() - arrival_date.getTime(), TimeUnit.MILLISECONDS)+1;
    }

    public long getFloorFee() {
        char floor = id_room.charAt(0);
        if(floor == '1') return 25;
		if(floor == '2') return 34;
		if(floor == '3') return 50;
		return 80;
    }

    public long getTotal() {
        return getFloorFee()*getDays()+service_fee;
    }

    @Override
    public String toString() {
        return id_customer + " " + name + " " + id_room + " " + getDays() + " " + getTotal();
    }

    @Override
    public int compareTo(Bill o) {
        if (this.getTotal() > o.getTotal()) return -1;
        return 1;
    }
    
    
}