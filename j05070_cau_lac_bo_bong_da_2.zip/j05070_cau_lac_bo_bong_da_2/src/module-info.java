/**
 * 
 */
/**
 * @author chaum
 *
 */
module j05070_cau_lac_bo_bong_da_2 {
}