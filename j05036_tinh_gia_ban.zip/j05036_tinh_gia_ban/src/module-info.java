/**
 * 
 */
/**
 * @author chaum
 *
 */
module j05036_tinh_gia_ban {
}