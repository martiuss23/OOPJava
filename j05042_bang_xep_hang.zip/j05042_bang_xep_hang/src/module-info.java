/**
 * 
 */
/**
 * @author chaum
 *
 */
module j05042_bang_xep_hang {
}