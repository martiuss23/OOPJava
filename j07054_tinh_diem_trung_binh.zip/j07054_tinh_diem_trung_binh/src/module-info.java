/**
 * 
 */
/**
 * @author chaum
 *
 */
module j07054_tinh_diem_trung_binh {
}