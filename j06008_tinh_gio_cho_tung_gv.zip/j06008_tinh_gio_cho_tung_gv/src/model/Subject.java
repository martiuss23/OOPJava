package model;

public class Subject {
	private String id;
	private String name;
	
	public Subject(String id, String name) {
		this.id = id;
		this.name = name;
	}
	
	String getName() {
		return name;
	}
	
	String getID() {
		return id;
	}
	
	
}
