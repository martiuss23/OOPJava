/**
 * 
 */
/**
 * @author chaum
 *
 */
module j08012_hinh_sao {
}