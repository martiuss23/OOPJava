/**
 * 
 */
/**
 * @author chaum
 *
 */
module j06008_bang_tinh_gio_chuan {
}