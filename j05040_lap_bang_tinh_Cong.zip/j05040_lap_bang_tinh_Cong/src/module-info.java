/**
 * 
 */
/**
 * @author chaum
 *
 */
module j05040_lap_bang_tinh_Cong {
}