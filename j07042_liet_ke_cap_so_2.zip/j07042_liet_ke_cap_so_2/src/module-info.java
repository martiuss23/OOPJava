/**
 * 
 */
/**
 * @author chaum
 *
 */
module j07042_liet_ke_cap_so_2 {
}