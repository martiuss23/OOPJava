/**
 * 
 */
/**
 * @author chaum
 *
 */
module j05046_bang_ke_nhap_kho {
}