/**
 * 
 */
/**
 * @author chaum
 *
 */
module j05043_tinh_thu_nhap_cho_nhan_vien {
}