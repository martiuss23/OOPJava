/**
 * 
 */
/**
 * @author chaum
 *
 */
module j05031_bang_diem_thanh_phan_2 {
}