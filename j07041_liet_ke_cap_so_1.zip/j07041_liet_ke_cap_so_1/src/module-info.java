/**
 * 
 */
/**
 * @author chaum
 *
 */
module j07041_liet_ke_cap_so_1 {
}