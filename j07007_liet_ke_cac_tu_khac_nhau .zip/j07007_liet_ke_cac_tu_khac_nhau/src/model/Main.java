package model;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;
import java.util.TreeSet;

public class Main {
	public static void main(String[] args) throws IOException {
        WordSet ws = new WordSet("VANBAN.in");
        System.out.println(ws);
    }
}
//E:\\OOPJava\\j07007_liet_ke_cac_tu_khac_nhau\\src\\model\\VANBAN.in