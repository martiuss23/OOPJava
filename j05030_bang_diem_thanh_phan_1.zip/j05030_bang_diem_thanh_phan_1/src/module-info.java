/**
 * 
 */
/**
 * @author chaum
 *
 */
module j05030_bang_diem_thanh_phan_1 {
}