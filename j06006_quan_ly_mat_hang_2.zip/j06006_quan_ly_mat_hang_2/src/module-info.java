/**
 * 
 */
/**
 * @author chaum
 *
 */
module j06006_quan_ly_mat_hang_2 {
}