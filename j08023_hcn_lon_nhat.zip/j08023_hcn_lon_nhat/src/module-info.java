/**
 * 
 */
/**
 * @author chaum
 *
 */
module j008023_hcn_lon_nhat {
}