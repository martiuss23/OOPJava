/**
 * 
 */
/**
 * @author chaum
 *
 */
module j07056_tinh_tien_dien {
}