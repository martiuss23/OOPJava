/**
 * 
 */
/**
 * @author chaum
 *
 */
module j07045_loai_phong {
}