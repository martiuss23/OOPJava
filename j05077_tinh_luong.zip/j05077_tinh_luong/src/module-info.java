/**
 * 
 */
/**
 * @author chaum
 *
 */
module j05077_tinh_luong {
}