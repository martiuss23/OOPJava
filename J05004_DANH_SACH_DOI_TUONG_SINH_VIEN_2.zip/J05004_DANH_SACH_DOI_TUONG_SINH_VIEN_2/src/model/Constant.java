package model;

public class Constant {
	public static String ID = "B20DCCN";
	
}
