/**
 * 
 */
/**
 * @author chaum
 *
 */
module j05060_ket_qua_xet_tuyen {
}