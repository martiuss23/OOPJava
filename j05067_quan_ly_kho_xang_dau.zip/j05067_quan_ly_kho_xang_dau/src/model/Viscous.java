package model;

public class Viscous extends Fuel{

	public Viscous(String manufacturerID) {
		super(manufacturerID);
		this.unitPrice = 9700;
		this.tax = 0.02;
		// TODO Auto-generated constructor stub
	}

}
