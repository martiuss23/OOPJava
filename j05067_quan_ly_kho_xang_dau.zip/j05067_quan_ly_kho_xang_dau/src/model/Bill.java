package model;

public class Bill {
	private String bID;
	private Fuel fuel;
	private int quantity;
	
	Bill(String bID, int quantity){
		this.bID = bID;
		if(bID.startsWith("N")) fuel = new Viscous(bID);
		else if(bID.startsWith("D")) fuel = new Oil(bID);
		else fuel = new Gas(bID);
		this.quantity = quantity;
		
	}
	
	long getRowCost() {
		return fuel.getUnitPrice() * quantity;
	}
	
	long getTotal() {
		return (long) (getRowCost() + getTaxCost());
	}
	
	long getTaxCost() {
		return (long) (getRowCost() * fuel.getTax());
	}
	
	@Override
	public String toString() {
		return bID + " " + fuel.getManufacturerName() + " " + fuel.getUnitPrice() + " " + getTaxCost() + " " + getTotal() ;
	}
}
