package model;

public class AscendingNumberException extends Exception{

}
