package model;

import java.util.ArrayList;
import java.util.List;
import java.util.TreeMap;
import java.util.TreeSet;

public class Subject {
	private String sID;
	private String name;
	private TreeSet<Group> groups;
	
	Subject(String sID, String name) {
		this.sID = sID;
		this.name = name;
		groups = new TreeSet<>();
	}
	
	public void addGroup(Group group) {
		groups.add(group);
	}
	
	public String getID() {
		return sID;
	}
	
	@Override
	public String toString() {
		StringBuilder sbd = new StringBuilder("Danh sach nhom lop mon " + name + ":\n");
		for(Group group: groups) {
			sbd.append(group + "\n");
		}
		return sbd.toString();
	}
	
}
