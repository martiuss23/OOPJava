package model;

import java.util.HashMap;
import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		int nbOfGroup = Integer.parseInt(scn.nextLine());
		HashMap<String, Subject> subjects = new HashMap<>();
		for(int i = 0; i < nbOfGroup; i++) {
			Subject sj = new Subject(scn.nextLine(), scn.nextLine());
			if(!subjects.containsKey(sj.getID())) {
				subjects.put(sj.getID(), sj);
			}
			subjects.get(sj.getID()).addGroup(new Group(scn.nextLine(), scn.nextLine()));
		}
		int query = Integer.parseInt(scn.nextLine());
		while(query-- > 0) {
			Subject sub = subjects.get(scn.nextLine());
			System.out.println(sub);
		}
	}
}

//4
//THCS2D20
//Tin hoc co so 2 - D20
//01
//Nguyen Binh An
//CPPD20
//Ngon ngu lap trinh C++ - D20
//01
//Le Van Cong
//THCS2D20
//Tin hoc co so 2 - D20
//02
//Nguyen Trung Binh
//LTHDTD19
//Lap trinh huong doi tuong - D19
//01
//Nguyen Binh An
//1
//THCS2D20