package model;

public class Group implements Comparable<Group> {
	private String gID;
	private String lectureName;
	
	Group(String gID, String lectureName) {
		this.gID = gID;
		this.lectureName = lectureName;
	}
	
	public String getID() {
		return gID;
	}
	
	@Override
	public String toString() {
		return gID + " " + lectureName;
	}

	@Override
	public int compareTo(Group o) {
		return gID.compareTo(o.gID);
	}
}
