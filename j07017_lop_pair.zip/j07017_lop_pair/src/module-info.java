/**
 * 
 */
/**
 * @author chaum
 *
 */
module j07017_lop_pair {
}