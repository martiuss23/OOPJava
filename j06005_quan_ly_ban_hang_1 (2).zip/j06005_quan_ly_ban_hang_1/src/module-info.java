/**
 * 
 */
/**
 * @author chaum
 *
 */
module j06005_quan_ly_ban_hang_1 {
}