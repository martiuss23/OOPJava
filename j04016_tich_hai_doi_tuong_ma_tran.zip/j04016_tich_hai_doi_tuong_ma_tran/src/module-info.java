/**
 * 
 */
/**
 * @author chaum
 *
 */
module j04016_tich_hai_doi_tuong_ma_tran {
}