/**
 * 
 */
/**
 * @author chaum
 *
 */
module j05050_tinh_tien_dien {
}