/**
 * 
 */
/**
 * @author chaum
 *
 */
module j04022_wordset {
}