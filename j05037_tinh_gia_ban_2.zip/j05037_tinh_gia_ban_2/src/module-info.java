/**
 * 
 */
/**
 * @author chaum
 *
 */
module j05037_tinh_gia_ban_2 {
}