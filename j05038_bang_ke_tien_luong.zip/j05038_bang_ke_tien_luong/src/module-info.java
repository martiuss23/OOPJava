/**
 * 
 */
/**
 * @author chaum
 *
 */
module j05038_bang_ke_tien_luong {
}