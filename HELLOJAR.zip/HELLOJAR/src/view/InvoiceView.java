package view;

import vn.edu.ptit.Invoice;

public class InvoiceView {
	
	public static void show(Invoice invoice) {
		System.out.println("Mã sinh viên: " + invoice.getStudentID());
		System.out.println("Họ tên: " + invoice.getStudentName());
		System.out.println("Các môn học:");
		for(String subject: invoice.getSubjectsName()) {
			System.out.println(subject);
		}
		System.out.println("Học phí phải nộp là: " + invoice.getCost());
		System.out.println("Theo QĐ: " + invoice.getRuleID());
	}
	
}
